import React from 'react';

export default function Profile() {
  return (
    <div className="container">
      <h2>Your Profile</h2>
      <p>Username: johndoe</p>
      <p>Email: johndoe@example.com</p>
    </div>
  );
}
