import express from 'express';
import {
  getReviewsByRestaurant,
  createReview,
  updateReview,
  deleteReview,
} from '../controllers/reviewsController.js';

import auth from '../middleware/auth.js'; // если есть авторизация

const router = express.Router();

// GET /api/v1/reviews/restaurant/:restaurantId
router.get('/restaurant/:restaurantId', getReviewsByRestaurant);

// POST /api/v1/reviews
router.post('/', auth, createReview);

// PUT /api/v1/reviews/:id
router.put('/:id', auth, updateReview);

// DELETE /api/v1/reviews/:id
router.delete('/:id', auth, deleteReview);

export default router;
