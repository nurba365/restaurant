import express from 'express';
import {
  getAllRestaurants,
  getRestaurantById,
  createRestaurant,
} from '../controllers/restaurantsController.js';

const router = express.Router();

// GET /api/v1/restaurants
router.get('/', getAllRestaurants);

// GET /api/v1/restaurants/:id
router.get('/:id', getRestaurantById);

// POST /api/v1/restaurants
router.post('/', createRestaurant);

export default router;
